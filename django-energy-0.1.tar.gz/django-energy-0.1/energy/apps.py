from django.apps import AppConfig


class EnergyConfig(AppConfig):
    name = 'energy'
